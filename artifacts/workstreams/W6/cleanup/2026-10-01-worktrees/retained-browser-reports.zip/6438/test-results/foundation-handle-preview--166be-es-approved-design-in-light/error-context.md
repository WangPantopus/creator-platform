# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: foundation.spec.ts >> handle-preview catalog matches approved design in light
- Location: tests/visual/foundation.spec.ts:36:9

# Error details

```
Error: expect(Buffer).toMatchSnapshot(expected) failed

  1 pixels (ratio 0.01 of all image pixels) are different.

  Snapshot: handle-preview.light.png

```

# Test source

```ts
  1   | import { test, expect } from "@playwright/test";
  2   | const origin = process.env.VISUAL_APP_ORIGIN ?? "http://localhost:3000";
  3   | const referenceOrigin =
  4   |   process.env.VISUAL_REFERENCE_ORIGIN ?? "http://127.0.0.1:3101";
  5   | 
  6   | // Approved artboards are catalog fixtures. Runtime routes depend on real public
  7   | // creator/arrival authority and must never fabricate Maya to satisfy snapshots.
  8   | const foundations = [
  9   |   {
  10  |     name: "welcome",
  11  |     group: "phase4a-fan-core",
  12  |     id: "Welcome",
  13  |     path: "/design/screens/phase4a-fan-core/Welcome?raw=1",
  14  |     width: 390,
  15  |     height: 844,
  16  |   },
  17  |   {
  18  |     name: "creator-home",
  19  |     group: "phase4a-fan-core",
  20  |     id: "Main",
  21  |     path: "/design/screens/phase4a-fan-core/Main?raw=1",
  22  |     width: 390,
  23  |     height: 1560,
  24  |   },
  25  |   {
  26  |     name: "handle-preview",
  27  |     group: "phase4a-fan-core",
  28  |     id: "Handle",
  29  |     path: "/design/screens/phase4a-fan-core/Handle?raw=1",
  30  |     width: 390,
  31  |     height: 844,
  32  |   },
  33  | ];
  34  | for (const theme of ["light", "night"] as const)
  35  |   for (const screen of foundations) {
  36  |     test(`${screen.name} catalog matches approved design in ${theme}`, async ({
  37  |       page,
  38  |       context,
  39  |     }) => {
  40  |       await page.setViewportSize({
  41  |         width: screen.width,
  42  |         height: screen.height,
  43  |       });
  44  |       await page.emulateMedia({
  45  |         colorScheme: theme === "night" ? "dark" : "light",
  46  |       });
  47  |       const reference = await context.newPage();
  48  |       await reference.setViewportSize({
  49  |         width: screen.width,
  50  |         height: screen.height,
  51  |       });
  52  |       await reference.goto(
  53  |         `${referenceOrigin}/${screen.group}/${screen.id}.dc.html`,
  54  |       );
  55  |       await reference.locator("x-dc").getByRole("heading").first().waitFor();
  56  |       await reference.evaluate((mode) => {
  57  |         document.documentElement.dataset.theme = mode;
  58  |       }, theme);
  59  |       await reference.evaluate(() => document.fonts.ready);
  60  |       const expected = await reference.screenshot({
  61  |         animations: "disabled",
  62  |         caret: "initial",
  63  |       });
> 64  |       expect(expected).toMatchSnapshot(`${screen.name}.${theme}.png`, {
      |                        ^ Error: expect(Buffer).toMatchSnapshot(expected) failed
  65  |         maxDiffPixels: 0,
  66  |       });
  67  |       await page.goto(
  68  |         `${origin}${screen.path}${screen.path.includes("?") ? "&" : "?"}theme=${theme}`,
  69  |       );
  70  |       await page.getByRole("heading").first().waitFor();
  71  |       await page.evaluate(() => document.fonts.ready);
  72  |       await page.screenshot({
  73  |         path: `test-results/${screen.name}-${theme}-implementation.png`,
  74  |         animations: "disabled",
  75  |         caret: "initial",
  76  |       });
  77  |       const actual = await page.screenshot({
  78  |         animations: "disabled",
  79  |         caret: "initial",
  80  |       });
  81  |       await test
  82  |         .info()
  83  |         .attach("implementation", { body: actual, contentType: "image/png" });
  84  |       await test
  85  |         .info()
  86  |         .attach("reference", { body: expected, contentType: "image/png" });
  87  |       expect(
  88  |         Buffer.compare(actual, expected),
  89  |         "Implementation pixels must match the independent reference exactly",
  90  |       ).toBe(0);
  91  |       await reference.close();
  92  |     });
  93  |   }
  94  | test("unconfigured Pantopus sign-in does not create a local identity and preserves arrival", async ({
  95  |   page,
  96  | }) => {
  97  |   await page.goto(`${origin}/auth/continue`);
  98  |   await expect(
  99  |     page.getByRole("button", {
  100 |       name: "Remove this post from your first message",
  101 |     }),
  102 |   ).toHaveCount(0);
  103 |   await page
  104 |     .getByRole("link", { name: "Continue with Pantopus", exact: true })
  105 |     .click();
  106 |   await expect(page).toHaveURL(/error=identity_unconfigured/);
  107 |   await expect(page.getByRole("alert")).toContainText("Pantopus sign-in");
  108 |   expect(new URL(page.url()).searchParams.get("returnTo")).toBe("/home");
  109 |   await page.goto(
  110 |     `${origin}/auth/continue?returnTo=%2Fcreators%2Fmaya%2Frequests`,
  111 |   );
  112 |   await page
  113 |     .getByRole("link", { name: "Continue with Pantopus", exact: true })
  114 |     .click();
  115 |   expect(new URL(page.url()).searchParams.get("returnTo")).toBe(
  116 |     "/creators/maya/requests",
  117 |   );
  118 |   await page.goto(`${origin}/onboarding/handle`);
  119 |   await expect(page).toHaveURL(/auth\/continue/);
  120 | });
  121 | 
```