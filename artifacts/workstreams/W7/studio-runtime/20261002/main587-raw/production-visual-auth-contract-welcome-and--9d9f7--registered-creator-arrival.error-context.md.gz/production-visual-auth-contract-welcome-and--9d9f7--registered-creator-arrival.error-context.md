# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: auth-contract.spec.ts >> welcome and auth seam preserve a registered creator arrival
- Location: tests/visual/auth-contract.spec.ts:42:5

# Error details

```
TypeError: Invalid URL
```

# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - main [ref=e2]:
    - generic [ref=e3]: Qelvora
    - generic [ref=e4]:
      - heading "Her AI answers you now. She answers in person when you ask." [level=1] [ref=e10]
      - paragraph [ref=e11]: "Every message says who wrote it: the creator's AI, the creator, or their team. You'll always know which."
    - generic [ref=e12]:
      - link "Continue with Pantopus" [ref=e13] [cursor=pointer]:
        - /url: /api/auth/continue?returnTo=%2Fcreators%2Fmaya%2Frequests%3Fcontext%3D00000000-0000-4000-8000-000000000001
      - paragraph [ref=e14]: One Pantopus account signs you in to every Pantopus app. New here? You'll create it in the next step.
  - alert [ref=e15]
```

# Test source

```ts
  1  | import { expect, test } from "@playwright/test";
  2  | 
  3  | const origin = process.env.VISUAL_APP_ORIGIN ?? "http://localhost:3000";
  4  | const fallback = "/home";
  5  | const invalidPaths = [
  6  |   "//outside.invalid",
  7  |   "https://outside.invalid",
  8  |   "/creators/maya/nested\\draft",
  9  |   "/creators/maya/nested\u0000draft",
  10 |   "/creators/maya/nested\tdraft",
  11 |   "/creators/maya/nested\r\ndraft",
  12 |   "/" + "x".repeat(2048),
  13 |   "/creators/maya/requests?draft=" + "x".repeat(1200),
  14 |   "/creators/maya?context=kiln",
  15 | ];
  16 | 
  17 | function authURL(path: string, returnTo: string) {
  18 |   const url = new URL(path, origin);
  19 |   url.searchParams.set("returnTo", returnTo);
  20 |   return url.toString();
  21 | }
  22 | 
  23 | test("auth seam rejects external, nested backslash and control-character contexts", async ({
  24 |   request,
  25 | }) => {
  26 |   for (const returnTo of invalidPaths) {
  27 |     const response = await request.get(
  28 |       authURL("/api/auth/continue", returnTo),
  29 |       {
  30 |         maxRedirects: 0,
  31 |       },
  32 |     );
  33 |     expect(response.status()).toBe(307);
  34 |     const redirected = new URL(response.headers().location!);
  35 |     expect(redirected.origin).toBe(origin);
  36 |     expect(redirected.pathname).toBe("/auth/continue");
  37 |     expect(redirected.searchParams.get("returnTo")).toBe(fallback);
  38 |     expect(redirected.searchParams.get("error")).toBe("invalid_return");
  39 |   }
  40 | });
  41 | 
  42 | test("welcome and auth seam preserve a registered creator arrival", async ({
  43 |   page,
  44 |   request,
  45 | }) => {
  46 |   const returnTo =
  47 |     "/creators/maya/requests?context=00000000-0000-4000-8000-000000000001";
  48 |   await page.goto(authURL("/auth/continue", returnTo));
  49 |   const link = page.getByRole("link", {
  50 |     name: "Continue with Pantopus",
  51 |     exact: true,
  52 |   });
  53 |   const continuation = new URL((await link.getAttribute("href"))!, origin);
  54 |   expect(continuation.searchParams.get("returnTo")).toBe(returnTo);
  55 |   const response = await request.get(continuation.toString(), {
  56 |     maxRedirects: 0,
  57 |   });
  58 |   expect(
> 59 |     new URL(response.headers().location!).searchParams.get("returnTo"),
     |     ^ TypeError: Invalid URL
  60 |   ).toBe(returnTo);
  61 | 
  62 |   await page.goto(authURL("/auth/continue", "/creators/maya/nested\\draft"));
  63 |   const fallbackLink = new URL((await link.getAttribute("href"))!, origin);
  64 |   expect(fallbackLink.searchParams.get("returnTo")).toBe(fallback);
  65 | });
  66 | 
```